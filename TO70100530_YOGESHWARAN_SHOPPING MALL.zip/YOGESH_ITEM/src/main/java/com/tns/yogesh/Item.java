package com.tns.yogesh;

import jakarta.persistence.*;

@Entity
@Table(name="item_details")
public class Item 
{
	@Id
	private Integer id;
	private String name;
	private String manufacture;
	private String expiry;
	private Integer price;
	private String category;
	
	public Item()
	{
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManufacture() {
		return manufacture;
	}

	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
	}

	public String getExpiry() {
		return expiry;
	}

	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Item [id=" + id + ", name=" + name + ", manufacture=" + manufacture + ", expiry=" + expiry + ", price="
				+ price + ", category=" + category + "]";
	}
	
}
